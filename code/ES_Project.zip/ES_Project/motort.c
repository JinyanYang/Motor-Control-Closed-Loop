#include "motort.h"
void Controller_Func_PI(Motor *Motorptr,Controller *Controlptr)
{
    float temp = 0;
    
    Controlptr->ek_1 = Controlptr->ek;//current error value becomes previous value
    Controlptr->ek = (signed int)(Motorptr->Desired - Motorptr->Actual);//New error value calculated
    
    Controlptr->uk_1 = Controlptr->uk;//current control value becomes previous value
    
    temp = (Controlptr->kpki*Controlptr->ek)-(Controlptr->kp*Controlptr->ek_1);
    Controlptr->uk = (unsigned char) (Controlptr->uk_1 + temp);//control value is updated
    
    if (Controlptr->uk > 95)
        Controlptr->uk = 95; //Note should never be above 100%
}
void Controller_Func_P(Motor *Motorptr, Controller *Controlptr)
{
    //float temp = 0;
    
    //Controlptr->ek_1 = Controlptr->ek;//current error value becomes previous value
    if (Motorptr->Desired >= Motorptr->Actual)
        Controlptr->ek = (signed int)( Motorptr->Desired - Motorptr->Actual);//New error value calculated
    else 
        Controlptr->ek = (signed int)(Motorptr->Actual - Motorptr->Desired);
    //Note error should always be positive in this case otherwise gain too high
    
   //Controlptr->uk_1 = Controlptr->uk;//current control value becomes previous value
    
    //temp = (Controlptr->kpki*Controlptr->ek)-(Controlptr->kp*Controlptr->ek_1);
    //Controlptr->uk = Controlptr->uk_1 + temp;//control value is updated
    Controlptr->uk = (unsigned char) (Controlptr->kp*Controlptr->ek);        //
    if (Controlptr->uk > 95)
        Controlptr->uk = 95;
}
