/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC18F46K22
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "../Buton_Debounce_and_LibraryFolders/Button_Debounce_Library/Buttons_Debounce.h"
#include "../motort.h"
/*
                         Main application
 */

//Function Phototype
void FLASH_LEDS(unsigned char secs);

//MAcros 
#define HEARTBEAT PORTEbits.RE0
#define DEBUG_LED PORTEbits.RE1
#define SELECT_F Button_Press.B1
#define TMR1_CLK 500000

//Global Variables
__bit TICK_E = 0;
Button_Type Button_Press;
unsigned int CCP2_Captured_Value = 0;
__bit Captured_Flag = 0; 

void TMR0_ISR_10ms(void)
{
    static unsigned char count = 0;
    TICK_E = 1; 
    Find_Button_Press();
    count++;
    if (count == 100)
    {
        count = 0;
        HEARTBEAT = ~HEARTBEAT;
    }
}

void main(void)
{
    // Initialize the device
    typedef enum {SETUP_S, OPEN_S, CLOSED_S } States_T;
    States_T State_Mch = SETUP_S;
    
    unsigned char count = 0;
    unsigned char ch = '1';   //declare another variable for convenience 
    unsigned int Choice = 0;
    unsigned int PWM_Duty[2] = {50,50};
    unsigned int Desired_Value[2] = {0,0};
    unsigned int i=0;
    unsigned char j = 0;
    Motor Motor1;
    Motor1.Desired =50;    //some initial values
    Motor1.Actual = 10;
    unsigned int Freq=0;
    unsigned int RPM =0;
    Controller Control1;
    Control1.kp = 0.9;
    Control1.ki = 0.1;
    Control1.kpki = Control1.kp + Control1.ki;
    Control1.ek = 0;
    Control1.ek_1 = 0;
    Control1.uk = 30;
    Control1.uk_1 = 30;
    Motor1.Desired =120;    //RPM
    Motor1.Actual = 10; //just start
       
    
    SYSTEM_Initialize();
    EPWM1_LoadDutyValue(0);
    FLASH_LEDS(3);
    TMR0_SetInterruptHandler(TMR0_ISR_10ms);
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

    printf ("\r\nMotor Controller Program Starting \r\n");   //Takes ~1 ms
    DELAY_milliseconds(3000);
    
    while (1)
    {
        // Add your application code
        /*if (SELECT) 
        { 
            SELECT = 0; 
            DEBUG_LED = ~DEBUG_LED; 
        }*/
        while (!TICK_E);
        /*printf("%d\r\n",count);       //3 
        count++;*/                     //4 
        switch (State_Mch) 
        { 
            case SETUP_S: 
                //OnEntry actions for the SETUP_S common from any state 
                INTERRUPT_GlobalInterruptDisable();
                EPWM1_LoadDutyValue(0);
                printf ("\n Enter Choice. 1 - Open Loop , 2 - Closed Loop \r\n");
                //scanf("%d",&Choice);
                ch = EUSART1_Read();
                if (ch == '1') 

                { 
                    State_Mch = OPEN_S;    //OnEntry Actions here when going to OPEN_S
                    printf("\n Running Open Loop Control\r\n");
                    printf("Enter PWM value 1 (40 to 80)> \r\n");
                    scanf("%d",&PWM_Duty[0]);
                    printf("Enter PWM value 2 (40 to 80)> \r\n");
                    scanf("%d",&PWM_Duty[1]);
                    j=0;
                    EPWM1_LoadDutyValue(PWM_Duty[j]*8);
                }
                else 
                { 
                    State_Mch = CLOSED_S;  //OnEntry Actions here when going to CLOSED_S
                    printf("\nRunning Closed Loop PI Control\r\n");
                    printf ("\n Enter Desired RRM Value 1 (100 to 250)> \r\n");
                    scanf("%d",&Desired_Value[0]);
                    printf ("\n Enter Desired RRM Value 2 (100 to 250)> \r\n");
                    scanf("%d",&Desired_Value[1]);
                    Motor1.Desired = Desired_Value[0];
                    j=0;i=0;
                    EPWM1_LoadDutyValue(40*8);  //40% duty cycle to start
                } 

                SELECT_F = 0;   //OnExit Action
                INTERRUPT_GlobalInterruptEnable();
                break;
            case OPEN_S:
                if (SELECT_F)
                {
                    State_Mch = SETUP_S; 
                    EPWM1_LoadDutyValue(0);   //Turn off Motor
                 }
                /*i++;
                if (i==500)  //100 is 1 sec, 500 is 5 sec, 1000 is 10 sec
                { 
                    //printf("Running Open \r\n");
                    j=!j;
                    EPWM1_LoadDutyValue(PWM_Duty[j]*8);
                    i=0;
                }*/
                
                break;        
            case CLOSED_S: 
                if (SELECT_F) 
                { 
                    State_Mch = SETUP_S;
                    EPWM1_LoadDutyValue(0);   //Turn off Motor
                }
                break;
            default:
                State_Mch = SETUP_S;
                break;
        }         
        //Do actions 
        switch (State_Mch) 
        { 
            case SETUP_S: 
                //no Do actions since never stay in this state 
                break;
            case OPEN_S:
               //DO Actions
                
                /*if (i==100)
                { 
                    printf("Running Open \r\n"); 
                    i=0;
                }*/
                i++;           
                if (i==1000)  //100 is 1 sec, 500 is 5 sec, 1000 is 10 sec 
                { 
                    //printf("Running Open \r\n");
                    j=!j;
                    EPWM1_LoadDutyValue(PWM_Duty[j]*8);
                    i=0;
                }
                if (Captured_Flag) 
                    { 
                        Freq = (unsigned int)(TMR1_CLK/CCP2_Captured_Value);  //Freq value could be int but not long 
                        RPM = (Freq * 5)/2;            //multiply by 2.5 since multiply by 60(secs to minutes)/24 (pulses per rev) 
                        Motor1.Actual = RPM;
                        Captured_Flag = 0;
                    }
                  if (i%10 == 0) //every 100 ms
                    { 
                        printf("%d",PWM_Duty[j] ); //PWM 
                        printf("\t\t");
                        printf("%d\r\n",Motor1.Actual);
                        //printf("\t\t");
                        //printf("%d\r\n",i);
                    }
                break;
            case CLOSED_S:
               //Do Actions here
                i++;
                /*if (i==100)
                { 
                    printf("Running Close \r\n"); 
                    i=0;
                }*/
                if (i==500)  //100 is 1 sec, 500 is 5 sec, 1000 is 10 sec 
                { 
                    //printf("Running Open \r\n");
                    j=!j;
                    Motor1.Desired = Desired_Value[j];
                    i=0;
                }
                if (Captured_Flag) 
                    { 
                        Freq = (unsigned int)(TMR1_CLK/CCP2_Captured_Value);  //Freq value could be int but not long 
                        RPM = (Freq * 5)/2;            //multiply by 2.5 since multiply by 60(secs to minutes)/24 (pulses per rev) 
                        Motor1.Actual = RPM;
                        Captured_Flag = 0;
                        Controller_Func_PI(&Motor1,&Control1);
                        EPWM1_LoadDutyValue(Control1.uk*8);
                    }
                  if (i%10 == 0) //every 100 ms
                    { 
                        printf("%d",Control1.uk ); //PWM 
                        printf("\t");
                        printf("%d",Motor1.Actual);
                        printf("\t");
                        printf("%d\r\n",Motor1.Desired);
                        //printf("%d\r\n",i);
                    }      
                break;
        }      
        TICK_E = 0;
    }
}

void FLASH_LEDS(unsigned char secs) 
{
    unsigned char i;
    for (i = 0; i < secs; i++)
    {
        PORTE = 0xFF;  // Turn all LEDs on
        DELAY_milliseconds(1000);  // Delay for 3000 milliseconds
        PORTE = 0x00;  // Turn all LEDs off
        //DELAY_milliseconds(1000);  // Delay for another 500 milliseconds
    }
}
/**
 End of File
*/