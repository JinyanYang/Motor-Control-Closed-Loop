# Button_Debounce_Library
 A state machine used to debounce all the buttons on a PORT
