/* 
 * File:   motort.h
 * Author: DKITStaff
 *
 * Created on December 20, 2022, 1:20 PM
 */

#ifndef MOTORT_H
#define	MOTORT_H

typedef struct{
    float kp;
    float ki;
    float kpki;   //kp + ki
    signed int ek;    //difference between desired RPM and Actual RPM
    signed int ek_1;
    unsigned char uk;   //New PWM value
    unsigned char uk_1; //Old PWM value;
} Controller;

typedef struct {
    unsigned int Desired;  //Desired RPM
    unsigned int Actual;   //Actual RPM
} Motor;

void Controller_Func_P(Motor *Motorptr, Controller *Controlptr);
void Controller_Func_PI(Motor *Motorptr, Controller *Controlptr);

#endif



